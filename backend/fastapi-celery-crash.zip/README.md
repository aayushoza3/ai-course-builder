# FastAPI + Celery Crash Course

demo

----

**Metadata**

- Status: `generating`
- Job ID: `383a14e1-25e3-482b-ac00-2ab830059e71`
- Created: `2025-08-15T21:00:02.576345`
